// ===============================
// Student Management System (Frontend)
// ===============================

// API endpoint (backend)
const API = "http://localhost:5000/students";

// App state
let editingId = null;
let students = [];

// ===============================
// Fetch and Render Students
// ===============================
async function fetchStudents() {
  try {
    const res = await fetch(API);
    students = await res.json();
    renderTable(students);
  } catch (err) {
    console.error("Error fetching students:", err);
  }
}

// ===============================
// Form Submission (Add / Update)
// ===============================
document.getElementById("studentForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  // Collect student data from form
  const student = {
    roll: document.getElementById("roll").value.trim(),
    name: document.getElementById("name").value.trim(),
    className: document.getElementById("className").value.trim(),
    fatherName: document.getElementById("fatherName").value.trim(),
    motherName: document.getElementById("motherName").value.trim(),
    dob: document.getElementById("dob").value,
    age: document.getElementById("age").value,
    address: document.getElementById("address").value.trim(),
  };

  try {
    if (editingId) {
      // Update existing student
      await fetch(`${API}/${editingId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(student),
      });
      editingId = null;
    } else {
      // Add new student
      await fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(student),
      });
    }
    fetchStudents();
    e.target.reset();
  } catch (err) {
    console.error("Error saving student:", err);
  }
});

// ===============================
// Render Student Table
// ===============================
function renderTable(students) {
  const tbody = document.querySelector("#studentTable tbody");
  tbody.innerHTML = "";

  students.forEach((s) => {
    const row = document.createElement("tr");

    row.innerHTML = `
      <td>${s.roll}</td>
      <td>${s.name}</td>
      <td>${s.className}</td>
      <td>${s.age}</td>
      <td>${s.fatherName}</td>
      <td>
        <button class="edit" onclick="editStudent(${s.id}, event)">✏️ Edit</button>
        <button class="delete" onclick="deleteStudent(${s.id}, event)">🗑️ Delete</button>
        <button class="promote" onclick="promoteStudent(${s.id}, event)">⬆️ Promote</button>
      </td>
    `;

    // Clicking anywhere on the row (except buttons) shows details
    row.addEventListener("click", () => showStudentDetails(s));
    tbody.appendChild(row);
  });
}

// ===============================
// Edit Student
// ===============================
function editStudent(id, event) {
  event.stopPropagation(); // Prevent triggering row click
  const student = students.find((s) => s.id === id);

  if (student) {
    document.getElementById("roll").value = student.roll;
    document.getElementById("name").value = student.name;
    document.getElementById("className").value = student.className;
    document.getElementById("fatherName").value = student.fatherName;
    document.getElementById("motherName").value = student.motherName;
    document.getElementById("dob").value = student.dob;
    document.getElementById("age").value = student.age;
    document.getElementById("address").value = student.address;
    editingId = id;
  }
}

// ===============================
// Auto-calculate Age from DOB
// ===============================
function calculateAge() {
  const dob = document.getElementById("dob").value;
  if (dob) {
    const birthDate = new Date(dob);
    const today = new Date();

    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();

    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--; // Adjust if birthday hasn’t occurred yet
    }

    document.getElementById("age").value = age;
  }
}

// ===============================
// Show Student Full Details
// ===============================
function showStudentDetails(student) {
  document.getElementById("d_roll").textContent = student.roll;
  document.getElementById("d_name").textContent = student.name;
  document.getElementById("d_class").textContent = student.className;
  document.getElementById("d_father").textContent = student.fatherName;
  document.getElementById("d_mother").textContent = student.motherName;
  document.getElementById("d_dob").textContent = student.dob;
  document.getElementById("d_age").textContent = student.age;
  document.getElementById("d_address").textContent = student.address;

  document.getElementById("detailsTitle").style.display = "block";
  document.getElementById("studentDetails").style.display = "block";
}

// ===============================
// Delete Student
// ===============================
async function deleteStudent(id, event) {
  event.stopPropagation();
  if (!confirm("Are you sure you want to delete this student?")) return;

  try {
    await fetch(`${API}/${id}`, { method: "DELETE" });
    fetchStudents();
  } catch (err) {
    console.error("Error deleting student:", err);
  }
}

// ===============================
// Promote Student
// ===============================
async function promoteStudent(id, event) {
  event.stopPropagation();
  try {
    await fetch(`${API}/${id}/promote`, { method: "PUT" });
    fetchStudents();
  } catch (err) {
    console.error("Error promoting student:", err);
  }
}

// ===============================
// Initialize App
// ===============================
fetchStudents();