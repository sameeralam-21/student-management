// ===============================
// Student Management System (Backend)
// ===============================
const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(express.json());

// In-memory data (replace with DB later if needed)
let students = [];
let idCounter = 1;

// ===============================
// Routes
// ===============================

// Health check
app.get("/", (req, res) => {
  res.send("✅ Student Management Backend is running");
});

// Get all students
app.get("/students", (req, res) => {
  res.json(students);
});

// Add student
app.post("/students", (req, res) => {
  const { roll, name, className, fatherName, motherName, dob, age, address } = req.body;

  if (!roll || !name || !className || !fatherName) {
    return res.status(400).json({ error: "Missing required fields" });
  }

  const student = {
    id: idCounter++,
    roll,
    name,
    className,
    fatherName,
    motherName: motherName || "",
    dob: dob || "",
    age: age || "",
    address: address || "",
  };

  students.push(student);
  res.status(201).json(student);
});

// Update student
app.put("/students/:id", (req, res) => {
  const id = parseInt(req.params.id, 10);
  const index = students.findIndex((s) => s.id === id);

  if (index === -1) {
    return res.status(404).json({ error: "Student not found" });
  }

  students[index] = { ...students[index], ...req.body };
  res.json(students[index]);
});

// Delete student
app.delete("/students/:id", (req, res) => {
  const id = parseInt(req.params.id, 10);
  const initialLength = students.length;
  students = students.filter((s) => s.id !== id);

  if (students.length === initialLength) {
    return res.status(404).json({ error: "Student not found" });
  }

  res.json({ message: "Student deleted successfully" });
});

// Promote student (increment class if numeric)
app.put("/students/:id/promote", (req, res) => {
  const id = parseInt(req.params.id, 10);
  const student = students.find((s) => s.id === id);

  if (!student) {
    return res.status(404).json({ error: "Student not found" });
  }

  const currentClass = parseInt(student.className, 10);
  if (!isNaN(currentClass)) {
    student.className = (currentClass + 1).toString();
  } else {
    // If class is not numeric (e.g., "KG"), keep as is
    student.className = student.className;
  }

  res.json(student);
});

// ===============================
// Start Server
// ===============================
app.listen(PORT, () => {
  console.log(`🚀 Backend running on http://localhost:${PORT}`);
});